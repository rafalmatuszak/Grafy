Program zosta� opracowany w j�zyku Python.

Zawiera metod� reukrencyjn� do wyznaczania elementu ze zbioru nieuporz�dkowanego. Opiera si� o podzia� zbioru na podzbiory i 
wyznaczaniu median tych podzbior�w. 

Program umo�lwia przetestowanie na liczbach generowanych losowo jak i na liczbach gotowych w za��czonym pliku CSV 
(gotowych jest 5 zestawow po 1000 elementow).