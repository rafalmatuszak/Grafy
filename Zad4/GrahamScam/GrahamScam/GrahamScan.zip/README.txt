Program zosta� opracowany w j�zyku Python.

Zawiera on:
-definicj� metod GrahamScan, quicksort, determinant, polar_angle oraz plot_progress,

Program pobiera punkty z wpisanych w skrypcie list.