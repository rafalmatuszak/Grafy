Program zosta� opracowany w j�zyku Python.

Zawiera on:
-definicj� klasy dla Punktu i W�z�a,
-metody: por�wnania punktow wzgledem wybranej wspolrzednej, obliczania mediany zbioru punktow wzgledem wybranej wspolrzednej 
oraz budowania kd-drzewa

Program pobiera punkty z podanych plikow CSV, zakodowanych w sposob kolumna x -> wspolrzedne x, kolumna y -> wspolrzedne y.
Do kodu zalaczono dwa przykladowe zestawy danych.