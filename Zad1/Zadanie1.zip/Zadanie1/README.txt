Program zosta� opracowany w j�zyku Python.

Zawiera cztery istotne elementy:
-definicj� klasy Point, umo�liwiaj�cej �atwiejsze operowanie na punktach,
-definicj� funkcji isMaximum, isMinimum, isOrientationRight - do sprawdzania ekstremow lokalnych oraz punktu orientacji,
-petli glownej, sprawdzajacej maksima i szacujacej punkty okreslajace {0}-j�dro

Program pobiera punkty wielokata z podanych plikow CSV, zakodowanych w sposob kolumna x -> wspolrzedne x, kolumna y -> wspolrzedne y.
Do kodu zalaczono trzy przykladowe wielokaty.